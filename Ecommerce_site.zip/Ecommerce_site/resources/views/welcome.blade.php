<html>
<head>
    <link rel="style.css" href="{{asset('css/style.css')}}">
</head>
<body>
<h1> hello</h1>
<p> hello i am shreebisha.</p>
</body>
</html>
