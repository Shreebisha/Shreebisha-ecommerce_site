<html>
<head>
</head>
<body>
<h1>profile</h1>
<p>Username: <?php echo e($Username); ?></p>
</body>
</html>
<?php /**PATH C:\Larabel\Ecommerce_site\resources\views/profile.blade.php ENDPATH**/ ?>