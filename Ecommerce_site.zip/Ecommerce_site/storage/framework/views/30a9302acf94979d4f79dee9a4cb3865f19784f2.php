<!doctype html>

<head>
    <title>update</title>
</head>
<body>
<form method="post" action="<?php echo e(action([\App\Http\Controllers\PagesController::class,'store'])); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo e($student->id); ?>">
    <label>Name:</label>
    <input type="text" name="name" value="<?php echo e($student->name); ?>" required>
    <label> Address:</label>
    <input type="text" name="address" value="<?php echo e($student->address); ?>" required>
    <label>Age:</label>
    <input type="number" name="age" value="<?php echo e($student->age); ?>" required>
    <label>DOB:</label>
    <input type="date" name="dob" value="<?php echo e($student->dob); ?>"required>
    <input type="submit">
</form>
</body>
</html>

<?php /**PATH C:\Larabel\Ecommerce_site\resources\views/update.blade.php ENDPATH**/ ?>