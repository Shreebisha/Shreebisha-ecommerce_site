<html>
<head>
    <link rel="style.css" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
<h1> hello</h1>
<p> hello i am shreebisha.</p>
</body>
</html>
<?php /**PATH C:\Larabel\Ecommerce_site\resources\views/welcome.blade.php ENDPATH**/ ?>