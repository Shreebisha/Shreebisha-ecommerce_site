<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<a href="<?php echo e(url('/create')); ?>"><button>Create</button></a>
<table> <tr>
        <th> Name</th>
        <th> Address</th>
        <th> Age</th>
        <th> DOB</th>
        <th> Image</th>

    </tr>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($student->name); ?></td>
            <td><?php echo e($student->address); ?></td>
            <td><?php echo e($student->age); ?></td>
            <td><?php echo e($student->dob); ?></td>
            <td><?php echo e($student->image); ?></td>
            <td><img src="<?php echo e(asset('storage/image/'.$student->image)); ?>"/></td>
            <td><a><a href="<?php echo e(url('/edit/'.$student->id)); ?>" Edit</a> </td>
        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>
<?php /**PATH C:\Larabel\Ecommerce_site\resources\views/list.blade.php ENDPATH**/ ?>